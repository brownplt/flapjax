fvlogger
(c) 2005 davidfmiller
http://www.fivevoltlogic.com/code/log4js

http://www.mojavelinux.com/blog/archives/2005/01/javascript_logging_via_meta/